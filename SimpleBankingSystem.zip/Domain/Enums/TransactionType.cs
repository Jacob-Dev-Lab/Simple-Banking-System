﻿namespace SimpleBankingSystem.Domain.Enums
{
    public enum TransactionType
    {
        Deposit,
        Withdrawal
    }
}
