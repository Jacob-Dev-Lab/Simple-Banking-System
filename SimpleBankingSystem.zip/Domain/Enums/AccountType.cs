﻿namespace SimpleBankingSystem.Domain.Enums
{
    public enum AccountType
    {
        Savings,
        Current
    }
}
