﻿using SimpleBankingSystem.Application.Interfaces;
using SimpleBankingSystem.Domain.Entities;
using SimpleBankingSystem.Domain.Enums;
using SimpleBankingSystem.Domain.ErrorHandler;

namespace SimpleBankingSystem.Application.Service.AccountService
{
    public class AccountOperationService(IAccountRepository accountRepository, 
        ITransactionRepository transactionRepository) : IAccountOperationService
    {
        private readonly IAccountRepository _accountRepository = accountRepository;
        private readonly ITransactionRepository _transactionRepository = transactionRepository;

        /* The Deposit and Withdraw methods first retrieve the account using the provided account number. 
         * They then call the Deposit or Withdraw method on the account, which checks the business rules 
         * for the operation. If the rule check fails, they return a failure result. If the rule check passes, 
         * they create a new Transaction object with the appropriate details and add it to the 
         * transaction repository. They also link the transaction to the account and save the changes to 
         * the account repository. Finally, they return a success result. */

        public Result Deposit(string accountNumber, decimal amount)
        {
            var account = _accountRepository.GetAccountByAccountNumber(accountNumber);
            
            var ruleCheck = account.Deposit(amount);
            if (ruleCheck.IsFailure)
                return ruleCheck;

            Transaction transaction = new(accountNumber, amount, TransactionType.Deposit);
            _transactionRepository.Add(transaction);

            account.LinkTransaction(transaction.TransactionID);

            _accountRepository.Save();

            return Result.Success();
        }

        public Result Withdraw(string accountNumber, decimal amount)
        {
            var account = _accountRepository.GetAccountByAccountNumber(accountNumber);
            
            var ruleCheck = account.Withdraw(amount);
            if (ruleCheck.IsFailure)
                return ruleCheck;

            Transaction transaction = new(accountNumber, amount, TransactionType.Withdrawal);
            _transactionRepository.Add(transaction);

            account.LinkTransaction(transaction.TransactionID);

            _accountRepository.Save();

            return Result.Success();
        }
    }
}
