﻿namespace SimpleBankingSystem.Application.Interfaces
{
    public interface IBankApp
    {
        public void Run();
    }
}
