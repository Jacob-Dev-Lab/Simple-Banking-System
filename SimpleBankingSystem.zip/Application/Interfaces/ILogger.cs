﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleBankingSystem.Application.Interfaces
{
    public interface ILogger
    {
        public void LogInfo(string message);
    }
}
